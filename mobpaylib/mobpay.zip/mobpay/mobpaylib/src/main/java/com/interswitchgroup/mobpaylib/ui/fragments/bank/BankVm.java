package com.interswitchgroup.mobpaylib.ui.fragments.bank;

import android.app.Activity;
import android.arch.lifecycle.ViewModel;

import com.interswitchgroup.mobpaylib.MobPay;
import com.interswitchgroup.mobpaylib.model.Bank;
import com.interswitchgroup.mobpaylib.ui.fragments.card.PaymentVm;


public class BankVm extends ViewModel {
    private static String LOG_TAG = BankVm.class.getSimpleName();
//    TODO make it equity
    private String hoverAction = "5494a632";
    private PaymentVm paymentVm;
    private Bank bank;

    public BankVm() {
        this.bank = new Bank();
    }

    public String getHoverAction() {
        return hoverAction;
    }

    public void setHoverAction(String hoverAction) {
        this.hoverAction = hoverAction;
    }

    public PaymentVm getPaymentVm() {
        return paymentVm;
    }

    public void setPaymentVm(PaymentVm paymentVm) {
        this.paymentVm = paymentVm;
    }

    public Bank getBank() {
        return bank;
    }

    public void setBank(Bank bank) {
        this.bank = bank;
    }
}