package com.interswitchgroup.mobpaylib.model;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.interswitchgroup.mobpaylib.BR;

import java.io.Serializable;
import java.util.regex.Pattern;

public class Bank extends BaseObservable implements Serializable {
    private Type type;
    private String hoverAction;

    public Bank(Type type) {
        this.setType(type);
    }

    public Bank() {

    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        switch (type) {
            case EQUITY:
                this.hoverAction = "7f57de00";
                break;
            case STANCHART:
                this.hoverAction = "5ca83dbd";
                break;
            case KCB:
                this.hoverAction = "c09cf6ba";
                break;
            case STANBIC:
                this.hoverAction = "5853ebf2";
                break;
            default:
                throw new IllegalArgumentException("The type selected does not have a corresponding provider set");
        }
        this.type = type;
    }

    public enum Type {
        EQUITY("Equity"), STANCHART("Stanchart"), KCB("KCB"),STANBIC("Stanbic Bank");
        public String value;

        Type(String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return value;
        }
    }
}
